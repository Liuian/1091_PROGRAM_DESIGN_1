#ifndef PLAYER_H
#define PLAYER_H

#include <QObject>
using namespace std;

class player : public QObject
{
    Q_OBJECT

public:
    player();

signals:

public slots:

};

#endif // PLAYER_H
