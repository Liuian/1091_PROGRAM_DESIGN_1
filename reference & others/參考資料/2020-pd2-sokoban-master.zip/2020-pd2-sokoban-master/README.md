# 2020-pd2-sokoban
## Video link
https://youtu.be/RlreZ9HJaMw
## How to play
遊戲menu有四個按鈕，分別是level n(現在關卡),select level,buy background,Quit，<br>
點擊level n(現在關卡)進入遊戲關卡，點擊select level選擇關卡，點擊buy background<br>
買背景顏色，點擊Quit離開遊戲。按鍵盤上下左右鍵或WASD鍵控制玩家移動，總共有兩個關<br>
卡，推所有箱子至儲存點即為過關，過關點擊next level可進入下一個關卡，如果中途失誤<br>
可按restsrt鍵重新遊玩當前關卡，按menu鍵回主頁面。遊戲中玩家撿紙鈔coin數+1，若碰<br>
到炸彈coin數-1，並回到該關卡的起始位置。玩家進入menu頁面，點進buy background，<br>
可使用coin購買背景顏色，粉色背景$5,白色背景$10。<br>
## Features
1.Main menu:level n(現在關卡),select level,buy background,Quit,現有coin數<br>
2.Collection:撿紙鈔coin數+1，顯示在每關頁面左下角，menu頁面也有<br>
3.The number of steps:顯示在每關頁面的左下角，在coin數左側<br>
## Bonus
1.bomb:碰到炸彈coin數-1，玩家並回到該關卡的起始位置<br>
2.buy background:可以利用撿到的coin數買視窗的背景顏色，點進menu頁面的
buy background購買，粉色背景$5,白色背景$10<br>
3.level n(現在關卡):如果第n關過了,可進入n+1關，則menu頁面的按鈕會顯示level n+1<br>
4.select level :如果第n關過了，解鎖n+1關的按鈕<br>

